using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ReactInRazorApp.Web.App.Pages
{
    public class FetchDataModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
