var reactElement = React.createElement(AppComponents.FetchData, { playerType: 'react' });
ReactDOM.render(reactElement, document.getElementById("root"));