var reactElement = React.createElement(Components.RootComponent, { "name": "Home" });
ReactDOM.render(reactElement, document.getElementById("root"));