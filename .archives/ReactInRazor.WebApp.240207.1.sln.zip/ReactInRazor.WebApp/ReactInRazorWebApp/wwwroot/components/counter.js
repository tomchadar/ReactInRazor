var reactElement = React.createElement(AppComponents.Counter, { "name": "Ryan" });
ReactDOM.render(reactElement, document.getElementById("root"));