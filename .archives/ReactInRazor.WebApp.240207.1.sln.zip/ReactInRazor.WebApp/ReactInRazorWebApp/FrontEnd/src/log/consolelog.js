import { cloneDeep } from 'lodash-es';

//https://stackoverflow.com/a/32928812/3015974
var debugfunction = console.log.bind(window.console);

var vardebuglog= function() {
    if (window.console) {

        // Only run on the first time through - reset this function to the appropriate console.log helper
        if (Function.prototype.bind) {
            vardebuglog = Function.prototype.bind.call(window.console.log, window.console);
        }
        else {
            vardebuglog = function () {
                Function.prototype.apply.call(window.console.log, window.console, arguments);
            };
        }

        vardebuglog.apply(this, arguments);
    }
}
var formatlogblob = function (...args) {
    var messageConfig = ' ';
    var params = Array.isArray(args) ? args.slice():[];

/*
    if (args && args.length !== undefined) {
        if (args.length > 0) {
            if (typeof (args[0]) === 'string') {
                if (args[0].indexOf('color:') > 0) {
                    messageConfig = '%c ';
                }
            }
        }
    }
    */
    args.forEach((argument) => {
        const type = typeof (argument);
        switch (type) {
            case 'bigint':
            case 'number':
                messageConfig += '%d   ';
                break;
            case 'boolean':
                messageConfig += '%o   ';
                break;
            case 'string':
                messageConfig += '%s   ';
                break;

            case 'object':
            case 'undefined':
            default:
                messageConfig += '%o   ';
        }
    });
    return { fmt: messageConfig, args: params };// args: args };
};

var extractLineNumberFromStack = function (stack) {
    /// <summary>
    /// Get the line/filename detail from a Webkit stack trace.  See https://stackoverflow.com/a/3806596/1037948
    /// </summary>
    /// <param name="stack" type="String">the stack string</param>

    if (!stack) {
        return '?'; // fix undefined issue reported by @sigod
    }

    // correct line number according to how Log().write implemented
    var stackArray = stack.split('\n');
    if (!stackArray) {
        return '?';
    }
    if (stackArray.length<3) {
        return '?';
    }

    var line = stackArray[2];//stack.split('\n')[2];
    // fix for various display text
    line = (line.indexOf(' (') >= 0
        ? line.split(' (')[1].substring(0, line.length - 1)
        : line.split('at ')[1]
    );
    return line;
};

if (!window.debuglog) {
    window.debuglog = debugfunction;
}
if (!window.vardebug) {
    window.vardebug = vardebuglog;
}

//220830
if (!window.logblob) {
    window.logblob = formatlogblob;
}



class LogInstance {
    constructor(props) {
        this.conlog = {
            fmt: '', args: {}
        };//window.logblob(...props);
        this.fmt = this.conlog.fmt;
        this.args = this.conlog.args;
    }
}

if (!window.consolelog) {
    window.consolelog = function (...args) {
        var li = formatlogblob(...args);
        var logargs = li.args;//cloneDeep(li1.args);
        logargs.unshift('color: blue');
        logargs.unshift(li.fmt);//'%c %s %s %o');
        return logargs;
    }
}
if (!window.dlog) {
    window.dlog = {
        addFormatAndColor: function (logargs, fmt, colorDef) {
            /*
            if (logargs && logargs.length !== undefined) {
                if (logargs.length > 0) {
                    if (typeof (logargs[0]) === 'string') {
                        
                    }
                }
            }
            */
            logargs.unshift(fmt);
            logargs.unshift(colorDef);
            return logargs;
        },
        format: function (colorDef, ...args) {
            var li = formatlogblob(...args);
            var colorFmt = '%c '+li.fmt;
            var logargs = this.addFormatAndColor(li.args, colorDef, colorFmt);
            return logargs;
        },
        yellow: function (...args) {
            return this.format('color: #ffff00; font-weight:bold', ...args);
        },
        orange: function (...args) {
            return this.format('color: orange; font-weight:bold', ...args);
        },
        green: function (...args) {
            return this.format('color: green; font-weight:bold', ...args);
        },
        lime: function (...args) {
            return this.format('color: #00ff00; font-weight:bold', ...args);
        },
        blue: function (...args) {
            return this.format('color: blue; font-weight:bold', ...args);
        },
        red: function (...args) {
            return this.format('color: red; font-weight:bold', ...args);
        },
        cyan: function (...args) {
            return this.format('color: #00ffff; font-weight:bold', ...args);
        },
        magenta: function (...args) {
            return this.format('color: #ff00ff; font-weight:bold', ...args);
        },
        plain: function (...args) {
            var li = formatlogblob(...args);
            li.args.unshift(li.fmt);
            return li.args;
        },

    };
}

if (!console.fmtlog) {
    console.fmtlog = function (colorStyle, ...args) {
        //colorStyle = colorStyle || 'color:green;font-weight:bold';
        var messageConfig = (colorStyle) ? '%c ' : '';
        var params = [];

        params.push(messageConfig);
        params.push(colorStyle);
        args.forEach((argument) => {
            const type = typeof (argument);
            params.push(argument);
            switch (type) {
                case 'bigint':
                case 'number':
                    params[0] += '%d   ';
                    break;
                case 'boolean':
                    params[0] += '%o   ';
                    break;
                case 'string':
                    params[0] += '%s   ';
                    break;

                case 'object':
                case 'undefined':
                default:
                    params[0] += '%o   ';
            }
        });

        var fmtargs = { messageConfig, ...params };
        return params;
        return fmtargs;
        //return { messageConfig, ...params };
        //return { messageConfig, colorStyle, ...args };
    };
}

if (!console.logincolor) {
    console.logincolor = (color, ...args) => {
        var messageConfig = '%c%s   ';

        args.forEach((argument) => {
            const type = typeof (argument);
            switch (type) {
                case 'bigint':
                case 'number':
                    messageConfig += '%d   ';
                    break;
                case 'boolean':
                    messageConfig += '%o   ';
                    break;
                case 'string':
                    messageConfig += '%s   ';
                    break;

                case 'object':
                case 'undefined':
                default:
                    messageConfig += '%o   ';
            }
        });
        //var err = new Error();
        console.log(messageConfig, color, '[LOGGER]', ...args);
        //console.log(messageConfig, 'color: green; font-weight:bold', '[LOGGER]', ...args);
    };
}

//example
//console.loggreen('my message', 123, 'qwerty', { foo: 'bar' }, [1, 2, 3, 4, 5]);
if (!console.logbluesinglestring) {
    console.logbluesinglestring = (message) => {
        console.log('%c ' + message, 'color: blue; font-weight:bold');
    };
}
