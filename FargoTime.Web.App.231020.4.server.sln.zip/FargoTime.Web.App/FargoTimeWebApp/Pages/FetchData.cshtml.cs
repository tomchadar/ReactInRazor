using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FargoTime.Web.App.Pages
{
    public class FetchDataModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
