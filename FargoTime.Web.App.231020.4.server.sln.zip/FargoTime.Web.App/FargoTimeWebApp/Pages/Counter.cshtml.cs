using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FargoTime.Pages
{
    public class CounterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
